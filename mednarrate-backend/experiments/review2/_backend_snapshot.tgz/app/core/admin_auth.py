import uuid
from datetime import datetime, timezone
from typing import Callable, List

from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.admin import (
    AdminPermission,
    AdminRole,
    AdminRoleAssignment,
    AdminRolePermission,
    SensitiveAccessGrant,
)
from app.models.user import User, UserRole


PERMISSION_COMPATIBILITY = {
    "audit_logs:read": {"audit_logs:read", "audit_logs.view", "audit.view"},
    "break_glass.request": {"break_glass.request", "breakglass.request"},
    "break_glass.read": {"break_glass.read", "breakglass.manage"},
    "break_glass.revoke": {"break_glass.revoke", "breakglass.manage"},
    "approve_sensitive_access": {"approve_sensitive_access", "breakglass.manage"},
    "privacy:read": {"privacy:read", "privacy.view"},
    "privacy:manage": {"privacy:manage", "privacy.manage"},
    "feature_flags:read": {"feature_flags:read", "feature_flags.view"},
    "feature_flags:manage": {"feature_flags:manage", "feature_flags.manage"},
    "settings:read": {"settings:read", "settings.view", "configuration.view"},
    "settings:manage": {"settings:manage", "settings.manage"},
    "maintenance:manage": {"maintenance:manage", "settings.manage"},
    "announcements:read": {"announcements:read", "announcements.view"},
    "announcements:manage": {"announcements:manage", "announcements.manage"},
    "ai_config:read": {"ai_config:read", "ai.view"},
    "ai_config:manage": {"ai_config:manage", "ai.manage"},
    "users.delete": {"users.delete"},
    "users.force_logout": {"users.force_logout"},
    "users.change_role": {"users.change_role"},
    "users.reset_password": {"users.reset_password"},
    "break_glass.approve": {"break_glass.approve", "approve_sensitive_access", "breakglass.manage"},
}


def _accepted_permissions(permission: str) -> set[str]:
    return PERMISSION_COMPATIBILITY.get(permission, {permission})


class AdminContext:
    def __init__(self, user: User, permissions: List[str]):
        self.user = user
        self.permissions = set(permissions)
        self.is_super_admin = (
            "super_admin" in self.permissions or "Super Admin" in self.permissions
        )  # Simplified check

    @property
    def user_id(self) -> uuid.UUID:
        return self.user.id

    def has_permission(self, permission: str) -> bool:
        if self.is_super_admin:
            return True
        return bool(_accepted_permissions(permission) & self.permissions)


async def get_admin_context(
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
) -> AdminContext:
    """
    Ensures the user has the 'admin' UserRole and fetches their granular permissions.
    """
    if current_user.role != UserRole.admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Not an admin"
        )

    # Fetch permissions
    stmt = (
        select(AdminPermission.name)
        .select_from(AdminRoleAssignment)
        .join(
            AdminRolePermission,
            AdminRoleAssignment.role_id == AdminRolePermission.role_id,
        )
        .join(AdminPermission, AdminRolePermission.permission_id == AdminPermission.id)
        .where(AdminRoleAssignment.user_id == current_user.id)
    )
    result = await db.execute(stmt)
    permissions = [row[0] for row in result.all()]

    # Check if they are a super admin directly by role name (for bootstrap flexibility)
    stmt_roles = (
        select(AdminRole.name)
        .join(AdminRoleAssignment, AdminRole.id == AdminRoleAssignment.role_id)
        .where(AdminRoleAssignment.user_id == current_user.id)
    )
    roles = [row[0] for row in (await db.execute(stmt_roles)).all()]
    if "Super Admin" in roles:
        permissions.append("super_admin")

    return AdminContext(user=current_user, permissions=permissions)


def require_permission(permission: str) -> Callable:
    """
    Dependency that returns the AdminContext if the admin has the specified permission.
    """

    async def _require_permission(
        admin_ctx: AdminContext = Depends(get_admin_context),
    ) -> AdminContext:
        if not admin_ctx.has_permission(permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Missing required permission: {permission}",
            )
        return admin_ctx

    return _require_permission


def require_any_permission(permissions: List[str]) -> Callable:
    """
    Dependency that returns the AdminContext if the admin has ANY of the specified permissions.
    """

    async def _require_any(
        admin_ctx: AdminContext = Depends(get_admin_context),
    ) -> AdminContext:
        if admin_ctx.is_super_admin:
            return admin_ctx
        if not any(admin_ctx.has_permission(p) for p in permissions):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires one of permissions: {permissions}",
            )
        return admin_ctx

    return _require_any


from fastapi import Header
def require_step_up(x_step_up_token: str = Header(..., description="Step-up JWT token")) -> dict:
    from app.core.security import decode_step_up_token
    try:
        return decode_step_up_token(x_step_up_token)
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid step-up token")

async def require_active_step_up(
    admin_ctx: AdminContext = Depends(get_admin_context),
    step_up_payload: dict = Depends(require_step_up)
) -> AdminContext:
    if str(admin_ctx.user_id) != step_up_payload.get("sub"):
        raise HTTPException(status_code=401, detail="Step-up token does not match current user")
    if admin_ctx.user.session_version != step_up_payload.get("session_version"):
        raise HTTPException(status_code=401, detail="Step-up token session version is invalid")
    return admin_ctx


ALLOWED_SENSITIVE_RESOURCE_TYPES = {
    "medical_report",
    "medical_profile",
    "doctor_profile",
    "caregiver_profile",
    "chat_session"
}

async def validate_access_grant(
    admin_ctx: AdminContext, resource_type: str, resource_id: str, db: AsyncSession
) -> SensitiveAccessGrant:
    """
    Validates that the admin has an active, unexpired, scope-matching break-glass grant.
    Auto-expires grants lazily. Raises 403 on any violation.

    A super-admin must NOT silently bypass break-glass for sensitive PHI.
    """
    if resource_type not in ALLOWED_SENSITIVE_RESOURCE_TYPES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown sensitive resource type: {resource_type}",
        )

    now = datetime.now(timezone.utc).replace(tzinfo=None)

    stmt = (
        select(SensitiveAccessGrant)
        .where(
            SensitiveAccessGrant.admin_id == admin_ctx.user_id,
            SensitiveAccessGrant.resource_type == resource_type,
            SensitiveAccessGrant.status == "active",
            SensitiveAccessGrant.expires_at > now,
        )
        .where(
            (SensitiveAccessGrant.resource_id == resource_id)
            | (SensitiveAccessGrant.resource_id == "*")
        )
    )

    result = await db.execute(stmt)
    grant = result.scalars().first()

    if not grant:
        expired_stmt = select(SensitiveAccessGrant).where(
            SensitiveAccessGrant.admin_id == admin_ctx.user_id,
            SensitiveAccessGrant.resource_type == resource_type,
            (SensitiveAccessGrant.resource_id == resource_id) | (SensitiveAccessGrant.resource_id == "*")
        )
        expired_grant = (await db.execute(expired_stmt)).scalars().first()

        if expired_grant:
            if expired_grant.status == "requested":
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Sensitive access request is pending approval. Access denied.",
                )
            elif (
                expired_grant.status in ("expired", "revoked")
                or expired_grant.expires_at <= now
            ):
                if expired_grant.status == "active":
                    expired_grant.status = "expired"
                    db.add(expired_grant)
                    await db.commit()
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Sensitive access grant has {expired_grant.status}. Request new access.",
                )

        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No active sensitive access grant for this resource. Use break-glass to request access.",
        )

    return grant

