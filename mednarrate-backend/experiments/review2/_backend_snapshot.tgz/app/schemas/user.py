import re
import unicodedata
from datetime import date, datetime
from typing import Literal, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, field_validator

from app.models.user import UserRole


def validate_dob_string(v: Optional[str]) -> Optional[str]:
    if v is None or v.strip() == "":
        return None
    trimmed = v.strip()
    try:
        parsed_date = datetime.strptime(trimmed, "%Y-%m-%d").date()
    except ValueError:
        raise ValueError(
            "Invalid Date of Birth format or calendar date. Must be YYYY-MM-DD (e.g., 2006-05-20)."
        )

    if parsed_date > date.today():
        raise ValueError("Date of Birth cannot be in the future.")
    if parsed_date.year < 1900:
        raise ValueError("Date of Birth year must be 1900 or later.")
    return trimmed


VALID_BLOOD_GROUPS = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"}


def validate_blood_group_str(v: Optional[str]) -> Optional[str]:
    if v is None or v.strip() == "":
        return None
    normalized = v.strip().upper()
    if normalized not in VALID_BLOOD_GROUPS:
        raise ValueError(
            f"Invalid blood group: '{v}'. Must be one of: A+, A-, B+, B-, AB+, AB-, O+, O-"
        )
    return normalized


def _has_letter_or_digit(text: str) -> bool:
    """Unicode-aware: true for Latin as well as Devanagari, Telugu, Tamil, etc."""
    return any(ch.isalnum() for ch in text)


def _is_name_char(ch: str) -> bool:
    """Letters and combining marks (Indic vowel signs are category M*), plus
    whitespace and the punctuation commonly found in personal names."""
    if ch.isspace() or ch in ".'-\u2019":
        return True
    return unicodedata.category(ch)[0] in ("L", "M")


def validate_text_field_str(v: Optional[str]) -> Optional[str]:
    if v is None or v.strip() == "":
        return None
    trimmed = v.strip()
    if not _has_letter_or_digit(trimmed):
        raise ValueError("Field content cannot consist solely of special characters.")
    return trimmed


VALID_INDIAN_PHONE_REGEX = re.compile(r"^[6-9]\d{9}$")


def validate_indian_phone_str(v: Optional[str]) -> Optional[str]:
    if v is None:
        return None
    trimmed = v.strip()
    if trimmed == "" or not VALID_INDIAN_PHONE_REGEX.match(trimmed):
        raise ValueError("Please enter a valid 10-digit Indian mobile number.")
    return trimmed


def validate_emergency_name_str(v: Optional[str]) -> Optional[str]:
    if v is None:
        return None
    trimmed = v.strip()
    if (
        trimmed == ""
        or not any(ch.isalpha() for ch in trimmed)
        or not all(_is_name_char(ch) for ch in trimmed)
    ):
        raise ValueError("Please enter a valid full name containing letters.")
    return trimmed


class MedicalProfileBase(BaseModel):
    blood_group: Optional[str] = None
    known_allergies: Optional[str] = None
    chronic_conditions: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_phone: Optional[str] = None

    @field_validator("blood_group")
    @classmethod
    def validate_blood_group(cls, v: Optional[str]) -> Optional[str]:
        return validate_blood_group_str(v)

    @field_validator("known_allergies", "chronic_conditions")
    @classmethod
    def validate_text_fields(cls, v: Optional[str]) -> Optional[str]:
        return validate_text_field_str(v)

    @field_validator("emergency_contact_phone")
    @classmethod
    def validate_emergency_phone(cls, v: Optional[str]) -> Optional[str]:
        return validate_indian_phone_str(v)

    @field_validator("emergency_contact_name")
    @classmethod
    def validate_emergency_name(cls, v: Optional[str]) -> Optional[str]:
        return validate_emergency_name_str(v)


class MedicalProfileOut(MedicalProfileBase):
    id: UUID
    user_id: UUID

    model_config = ConfigDict(from_attributes=True)


class DoctorProfileBase(BaseModel):
    specialty: Optional[str] = None
    qualifications: Optional[str] = None
    license_number: Optional[str] = None
    years_of_experience: Optional[int] = None
    hospital: Optional[str] = None
    professional_address: Optional[str] = None
    bio: Optional[str] = None


class CaregiverProfileBase(BaseModel):
    relationship: Optional[str] = None
    caregiver_role: Optional[str] = None
    supported_patient_name: Optional[str] = None
    organization: Optional[str] = None


class UserBase(BaseModel):
    email: EmailStr
    full_name: str
    preferred_language: str = "en"
    date_of_birth: Optional[str] = None
    gender: Optional[str] = None

    @field_validator("date_of_birth")
    @classmethod
    def validate_dob(cls, v: Optional[str]) -> Optional[str]:
        return validate_dob_string(v)

    @field_validator("full_name")
    @classmethod
    def validate_full_name(cls, v: str) -> str:
        # Ensure full_name is non-empty and contains at least one alphanumeric char
        result = validate_text_field_str(v)
        if result is None:
            raise ValueError(
                "Full name must not be empty or consist solely of special characters."
            )
        return result


class UserOut(UserBase):
    id: UUID
    role: UserRole
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class AdminIdentityOut(UserOut):
    permissions: list[str] = []

    model_config = ConfigDict(from_attributes=True)


class UserWithProfileOut(UserOut):
    medical_profile: Optional[MedicalProfileOut] = None
    doctor_profile: Optional[DoctorProfileBase] = None
    caregiver_profile: Optional[CaregiverProfileBase] = None

    model_config = ConfigDict(from_attributes=True)


class UserUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    full_name: Optional[str] = None
    role: Optional[Literal["patient", "clinician"]] = None
    preferred_language: Optional[str] = None
    date_of_birth: Optional[str] = None
    gender: Optional[str] = None
    medical_profile: Optional[MedicalProfileBase] = None
    doctor_profile: Optional[DoctorProfileBase] = None
    caregiver_profile: Optional[CaregiverProfileBase] = None

    @field_validator("date_of_birth")
    @classmethod
    def validate_dob(cls, v: Optional[str]) -> Optional[str]:
        return validate_dob_string(v)

    @field_validator("full_name")
    @classmethod
    def validate_full_name(cls, v: Optional[str]) -> Optional[str]:
        # Allow None (no update), but validate if provided
        return validate_text_field_str(v)
