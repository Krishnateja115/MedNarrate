import asyncio
import json
import logging
import time
import uuid
from datetime import datetime, timezone

from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.core.config import settings
from app.core.database import AsyncSessionLocal
from app.core.timing import Stopwatch, record as record_timing
from app.models.report import ProcessingStatus, Report
from app.models.report_analysis import ReportAnalysis
from app.models.user import User
from app.schemas.report import AbnormalFinding, Entity, LabValue
from app.services.lab_value_extractor import (
    extract_lab_values,
    extract_medication_schedule,
)
from app.services.document_validation import validate_medical_document
from app.services.evidence_sources import build_lab_evidence_sources
from app.services.report_text_loader import extract_report_text
from app.services.provisional_lab_ranges import add_provisional_ranges
from app.services.llm_client import (
    LLMConfigurationError,
    LLMConnectionError,
    generate_with_metadata,
)
from app.services.model_registry import get_ner_pipeline
from app.services.privacy import deidentify_prompt_text
from app.services.prompts import (
    CLINICIAN_PROMPT,
    PATIENT_PROMPT,
    ROLE_INSTRUCTIONS,
    get_examples_text,
)
from app.services.rag import process_report_for_rag, retrieve_chunks
from app.services.report_date_extractor import extract_report_date
from app.services.text_extraction import (
    ExtractionError,
    clean_extracted_text,
)
from app.services.validation import validate_and_ground_analysis
from app.services.feature_flags import evaluate_flag

logger = logging.getLogger(__name__)


async def generate_with_timeout_metadata(
    prompt: str,
    timeout: int = 60,
    request_id: str | None = None,
    system_instruction: str | None = None,
    thinking_level: str = "LOW",
):
    """Executes single LLM call with request timeout and request correlation tracking, returning full metadata dict."""
    try:
        return await asyncio.wait_for(
            generate_with_metadata(
                prompt,
                timeout=timeout,
                request_id=request_id,
                system_instruction=system_instruction,
                thinking_level=thinking_level,
            ),
            timeout=timeout + 2.0,
        )
    except Exception:
        raise


async def generate_core_summaries(
    clinician_prompt: str,
    patient_prompt: str,
    clinician_instruction: str,
    patient_instruction: str,
    request_id: str,
) -> tuple[dict, dict]:
    """Generate independent summaries concurrently without changing their content."""
    return await asyncio.gather(
        generate_with_timeout_metadata(
            clinician_prompt,
            timeout=settings.LLM_TIMEOUT_SECONDS,
            request_id=request_id,
            system_instruction=clinician_instruction,
            thinking_level=settings.ANALYSIS_THINKING_LEVEL,
        ),
        generate_with_timeout_metadata(
            patient_prompt,
            timeout=settings.LLM_TIMEOUT_SECONDS,
            request_id=request_id,
            system_instruction=patient_instruction,
            thinking_level=settings.ANALYSIS_THINKING_LEVEL,
        ),
    )


async def _record_failure(
    db: AsyncSession, report_id: uuid.UUID, failure_cat: str, message: str
) -> None:
    """Persist a failed analysis state safely.

    The session may be in a failed/aborted transaction (e.g. a flush error), so
    roll back first and re-load the report by id instead of touching expired
    ORM instances. Never raises: a report must not remain stuck in
    ``processing`` because the failure handler itself failed.
    """
    try:
        await db.rollback()
        report = (
            await db.execute(select(Report).where(Report.id == report_id))
        ).scalars().first()
        if not report:
            return
        report.processing_status = ProcessingStatus.failed
        analysis = (
            await db.execute(
                select(ReportAnalysis).where(ReportAnalysis.report_id == report.id)
            )
        ).scalars().first()
        if not analysis:
            analysis = ReportAnalysis(report_id=report.id)
            db.add(analysis)
        analysis.error_reason = message[:2000]
        analysis.failure_category = failure_cat
        await db.commit()
    except Exception as rec_e:  # noqa: BLE001
        logger.error(
            f"[STAGE:FAIL] Could not record failure for report {report_id}: {rec_e!r}"
        )
        try:
            await db.rollback()
        except Exception:
            pass


async def run_analysis(report_id: uuid.UUID, db: AsyncSession = None):
    if db is None:
        async with AsyncSessionLocal() as session:
            return await run_analysis(report_id, session)

    req_id = str(uuid.uuid4())
    start_time = datetime.now(timezone.utc)
    watch = Stopwatch()
    med_task: asyncio.Task | None = None
    logger.info(
        f"[STAGE:START] req_id={req_id} Pipeline analysis started for report {report_id}"
    )

    try:
        stmt = select(Report).where(Report.id == report_id)
        result = await db.execute(stmt)
        report = result.scalars().first()

        if not report:
            logger.error(
                f"[STAGE:ERROR] req_id={req_id} Report {report_id} not found in database."
            )
            return

        report.processing_status = ProcessingStatus.processing
        await db.commit()

        # 1. Text Extraction & Diagnostic Handling
        watch.lap("setup")
        stage_started = time.perf_counter()
        file_type_str = (
            report.file_type.value
            if hasattr(report.file_type, "value")
            else str(report.file_type)
        )
        report_type_str = (
            report.report_type.value
            if hasattr(report.report_type, "value")
            else str(report.report_type)
        )

        logger.info(
            f"[STAGE:EXTRACTION] req_id={req_id} Processing file: {report.file_path} ({file_type_str})"
        )
        if not report.extracted_text or len(report.extracted_text.strip()) == 0:
            extracted = await extract_report_text(report.file_path, file_type_str)
            report.extracted_text = extracted

        cleaned_text = clean_extracted_text(report.extracted_text or "")
        validate_medical_document(cleaned_text)
        logger.info(
            f"[STAGE:EXTRACTION:SUCCESS] req_id={req_id} Extracted {len(cleaned_text)} characters in {time.perf_counter() - stage_started:.2f}s."
        )

        # Source-aware Report Date Extraction
        extracted_date = extract_report_date(cleaned_text, report.report_date)
        if extracted_date != report.report_date:
            report.report_date = extracted_date
            await db.commit()

        # 2. Run NER -> entities
        watch.lap("extraction")
        stage_started = time.perf_counter()
        logger.info(f"[STAGE:NLP] req_id={req_id} Running biomedical NER pipeline...")
        entities = []
        try:
            ner_pipeline = await asyncio.wait_for(
                asyncio.to_thread(get_ner_pipeline), timeout=30.0
            )
            entities_raw = await asyncio.wait_for(
                asyncio.to_thread(ner_pipeline, cleaned_text[:4000]), timeout=30.0
            )
            for ent in entities_raw:
                ent["score"] = float(ent["score"])
                try:
                    valid_ent = Entity(**ent).model_dump()
                    entities.append(valid_ent)
                except ValidationError:
                    logger.warning(
                        f"[STAGE:NLP:WARN] req_id={req_id} Discarding invalid entity (validation error)."
                    )
            logger.info(
                f"[STAGE:NLP:SUCCESS] req_id={req_id} Identified {len(entities)} entities in {time.perf_counter() - stage_started:.2f}s."
            )
        except asyncio.TimeoutError:
            logger.warning(
                f"[STAGE:NLP:TIMEOUT] req_id={req_id} NER loading or inference timed out after 30s. Continuing without NER entities."
            )
        except Exception as ner_e:
            logger.warning(
                f"[STAGE:NLP:FAIL] req_id={req_id} NER pipeline exception (continuing lab extraction): {ner_e}"
            )

        # 3. Extract Structured Lab Values & Abnormal Findings
        watch.lap("nlp")
        stage_started = time.perf_counter()
        logger.info(
            f"[STAGE:LAB_EXTRACT] req_id={req_id} Extracting structured lab parameters..."
        )
        raw_lab_values = await extract_lab_values(cleaned_text, report_type=report_type_str)
        structured_lab_values = []
        abnormal_findings = []

        for lab in raw_lab_values:
            try:
                valid_lab = LabValue(**lab).model_dump()
                structured_lab_values.append(valid_lab)

                if valid_lab["flag"] not in {"normal", "not_classified"}:
                    try:
                        valid_abnormal = AbnormalFinding(**lab).model_dump()
                        abnormal_findings.append(valid_abnormal)
                    except ValidationError:
                        logger.warning(
                            f"[STAGE:LAB_EXTRACT:WARN] req_id={req_id} Discarding invalid abnormal finding (validation error)."
                        )
                    except Exception:
                        pass
            except Exception:
                logger.warning(
                    f"[STAGE:LAB_EXTRACT:WARN] req_id={req_id} Discarding invalid lab value (validation error)."
                )

        logger.info(
            f"[STAGE:LAB_EXTRACT:SUCCESS] req_id={req_id} Extracted {len(structured_lab_values)} lab values ({len(abnormal_findings)} abnormal) in {time.perf_counter() - stage_started:.2f}s."
        )

        # 4. RAG Processing & Retrieval
        watch.lap("lab_extract")
        stage_started = time.perf_counter()
        logger.info(
            f"[STAGE:RAG] req_id={req_id} Processing report chunks for RAG index..."
        )
        retrieved_chunks_count = 0
        rag_context = ""
        try:
            await process_report_for_rag(report.id, cleaned_text, db)
            rag_context = await retrieve_chunks(
                query=cleaned_text[:500], report_id=report.id, db=db, top_k=3
            )
            if rag_context and rag_context.strip():
                retrieved_chunks_count = rag_context.count("[Chunk ")
            logger.info(
                f"[STAGE:RAG:SUCCESS] req_id={req_id} Report processed for RAG. Retrieved {retrieved_chunks_count} chunks in {time.perf_counter() - stage_started:.2f}s."
            )
        except Exception as rag_e:
            logger.warning(
                f"[STAGE:RAG:FAIL] req_id={req_id} RAG indexing/retrieval failed: {rag_e}"
            )

        # 5. User Role & Prompt Preparation with Privacy De-identification
        user_stmt = select(User).where(User.id == report.user_id)
        user_result = await db.execute(user_stmt)
        user = user_result.scalars().first()
        structured_lab_values = add_provisional_ranges(
            structured_lab_values,
            user.date_of_birth if user else None,
            report.report_date,
        )
        user_role = (
            (user.role.value if hasattr(user.role, "value") else str(user.role))
            if user
            else "patient"
        )

        # Apply Privacy boundary to report text before prompt assembly
        deidentified_text = deidentify_prompt_text(cleaned_text)

        structured_values_json = json.dumps(structured_lab_values, indent=2)

        provisional_instruction = (
            "Any lab value with reference_source=general_provisional uses a "
            "published general range, not a range supplied by the patient's "
            "laboratory. Clearly label that comparison as provisional; do not "
            "treat it as a diagnosis or a critical result.\n\n"
        )

        clinician_prompt = provisional_instruction + CLINICIAN_PROMPT.format(
            report_type=report_type_str,
            structured_values_json=structured_values_json,
            extracted_text=deidentified_text,
            rag_context=rag_context or "None",
        )

        role_instruction = ROLE_INSTRUCTIONS.get(
            user_role, ROLE_INSTRUCTIONS["patient"]
        )
        examples = get_examples_text()
        patient_prompt = provisional_instruction + PATIENT_PROMPT.format(
            report_type=report_type_str,
            extracted_text=deidentified_text,
            structured_values_json=structured_values_json,
            user_role=user_role,
            role_specific_instruction=role_instruction,
            rag_context=rag_context or "None",
            examples=examples,
        )

        # 6. LLM Generation with Request Correlation
        watch.lap("rag_and_prompt")
        stage_started = time.perf_counter()
        logger.info(
            f"[STAGE:LLM] req_id={req_id} Generating summaries via configured LLM provider..."
        )
        from app.services.llm_orchestrator import verify_medical_facts

        # The medication schedule only needs the report text, so it runs while
        # the two summaries are being generated instead of after them.
        med_task = asyncio.create_task(extract_medication_schedule(cleaned_text))
        med_task.add_done_callback(
            lambda t: t.cancelled() or t.exception()  # mark exception as retrieved
        )

        clinician_sys = "You are a specialized medical analysis AI. Strictly format your response according to the provided instructions. Do not hallucinate data. Maintain a formal, clinical tone."
        patient_sys = "You are an empathetic medical assistant. Explain medical terms clearly to a patient. Strictly follow the structure requested. Do not give direct medical advice."
        clinician_res, patient_res = await generate_core_summaries(
            clinician_prompt,
            patient_prompt,
            clinician_sys,
            patient_sys,
            req_id,
        )
        clinician_summary = clinician_res["content"]
        patient_summary = patient_res["content"]

        llm_provider = clinician_res.get("provider")
        llm_model = clinician_res.get("model")

        logger.info(
            f"[STAGE:LLM:SUCCESS] req_id={req_id} Generated clinician and patient summaries in {time.perf_counter() - stage_started:.2f}s."
        )
        watch.lap("llm_summaries")

        # 7. Medical Validation & Grounding Layer
        logger.info(
            "[STAGE:VALIDATION] Validating generated analysis against source document using Medical Verifier..."
        )
        # Old synchronous regex/heuristic validation
        validation_res = validate_and_ground_analysis(
            extracted_text=cleaned_text,
            structured_lab_values=structured_lab_values,
            patient_summary=patient_summary,
            clinician_summary=clinician_summary,
        )
        patient_summary = validation_res["patient_summary"]
        clinician_summary = validation_res["clinician_summary"]
        structured_lab_values = validation_res["structured_lab_values"]
        grounding_failed = bool(validation_res["unsupported_claims"])

        # NEW LLM-based verification using MedGemma (Medical Verifier)
        # We verify the clinician_summary as it is the most critical medical output
        verification_status = "invalid" if grounding_failed else "unverified"
        if grounding_failed:
            # Never present a summary containing ungrounded numbers or diagnoses
            # as safe output. Keep the record available for review, but make the
            # failure explicit to every client and downstream export.
            clinician_summary += (
                "\n\n[WARNING: Automated grounding found unsupported medical claims. "
                "Clinician review is required before use.]"
            )
            patient_summary += (
                "\n\n[Note: This summary contains claims that could not be verified "
                "against the uploaded report and requires clinician review.]"
            )
            logger.warning(
                "[STAGE:VALIDATION:FAILED] Grounding rejected unsupported claims; "
                "content remains explicitly unverified."
            )
        use_verifier = await evaluate_flag(db, "experimental_medical_verifier", user_id=str(report.user_id))
        if use_verifier:
            verification_result = await verify_medical_facts(
                clinician_summary, request_id=req_id
            )
            is_valid = verification_result["is_valid"]
            if not grounding_failed:
                verification_status = verification_result["verification_status"]

            if is_valid is False:
                # Verifier ran and detected dangerous errors
                clinician_summary += f"\n\n[WARNING from Medical Verifier]: {verification_result['correction']}"
                patient_summary += "\n\n[Note: This summary has been flagged by the automated verification system and requires doctor review.]"
                logger.warning(
                    "[STAGE:VALIDATION:FAILED] Medical Verifier flagged output. (Correction text omitted for privacy)."
                )
            elif is_valid is None:
                # Verifier unavailable or returned malformed response — content is UNVERIFIED
                # Do NOT present as medically verified. Log and continue without a false-valid label.
                logger.warning(
                    f"[STAGE:VALIDATION:UNVERIFIED] Medical Verifier unavailable (status={verification_status}). "
                    "Content is UNVERIFIED and will not be labelled as medically confirmed."
                )
            # is_valid is True: verifier confirmed content — proceed normally

        # Translation remains available on demand. Do not delay the first
        # usable report on two additional remote model calls.

        # Extract and persist medications
        try:
            from app.models.medication_schedule import MedicationSchedule

            watch.lap("validation")
            meds = await med_task
            watch.lap("medication_wait")
            if meds:
                # Re-analysis (force) must replace, not duplicate, the schedule
                # rows previously extracted from this same report.
                from sqlalchemy import delete as sa_delete

                await db.execute(
                    sa_delete(MedicationSchedule).where(
                        MedicationSchedule.report_id == report.id
                    )
                )
            for med in meds:
                db_med = MedicationSchedule(
                    report_id=report.id,
                    user_id=report.user_id,
                    medication_name=med.medication_name,
                    dosage=med.dosage,
                    frequency=med.frequency,
                    times_of_day=med.times_of_day,
                    duration_days=med.duration_days,
                    notes=med.notes,
                )
                db.add(db_med)
        except Exception as med_e:
            logger.warning(
                f"[STAGE:MEDICATION:WARN] Medication extraction failed: {med_e}"
            )

        # 8. Database Persistence & Final Completion
        stmt_analysis = select(ReportAnalysis).where(
            ReportAnalysis.report_id == report.id
        )
        res_analysis = await db.execute(stmt_analysis)
        analysis = res_analysis.scalars().first()

        if not analysis:
            analysis = ReportAnalysis(report_id=report.id)
            db.add(analysis)

        analysis.structured_lab_values = structured_lab_values
        analysis.entities = entities
        analysis.abnormal_findings = abnormal_findings
        analysis.evidence_sources = build_lab_evidence_sources(
            cleaned_text, structured_lab_values
        )
        analysis.clinician_summary = clinician_summary
        analysis.verification_status = verification_status
        analysis.patient_summary = patient_summary
        analysis.llm_provider = llm_provider
        analysis.llm_model = llm_model
        analysis.processed_at = datetime.now(timezone.utc).replace(tzinfo=None)
        analysis.error_reason = None

        report.processing_status = ProcessingStatus.completed
        await db.commit()

        watch.lap("persist")
        duration = (datetime.now(timezone.utc) - start_time).total_seconds()
        logger.info(
            f"[STAGE:COMPLETE] Report {report_id} analysis completed successfully in {duration:.2f}s."
        )
        record_timing(
            "ANALYSIS",
            "report_analysis",
            watch.total_ms(),
            **{f"{k}_ms": v for k, v in watch.laps_ms.items()},
            provider=llm_provider,
            model=llm_model,
            chars=len(cleaned_text),
            summary_calls_ms=max(
                int(clinician_res.get("latency_ms") or 0),
                int(patient_res.get("latency_ms") or 0),
            ),
        )

    except ExtractionError as ee:
        failure_cat = getattr(ee, "failure_category", "EXTRACTION_ERROR")
        logger.error(
            f"[STAGE:FAIL] Extraction failed for report {report_id} [{failure_cat}]: {ee}"
        )
        # ExtractionError messages are written to be user-facing.
        await _record_failure(db, report_id, failure_cat, str(ee))

    except (LLMConfigurationError, LLMConnectionError) as llm_e:
        # LLM not configured or unreachable - store a clean, user-facing message
        # instead of the raw traceback that the generic handler would produce.
        is_config_error = isinstance(llm_e, LLMConfigurationError)
        failure_cat = (
            "LLM_NOT_CONFIGURED" if is_config_error else "LLM_GENERATION_ERROR"
        )
        clean_msg = (
            "AI analysis is unavailable: the AI service is not configured on this server. "
            "Please contact support."
            if is_config_error
            else "AI analysis failed because the AI service could not be reached. Please try again later."
        )
        logger.error(
            f"[STAGE:FAIL] LLM error for report {report_id} [{failure_cat}]: {llm_e}"
        )
        await _record_failure(db, report_id, failure_cat, clean_msg)

    except Exception as e:
        import traceback

        failure_cat = getattr(e, "failure_category", "PIPELINE_ERROR")
        logger.error(
            f"[STAGE:FAIL] Pipeline failed for report {report_id}: {repr(e)}\n{traceback.format_exc()}"
        )
        # Never persist raw exception text (can contain SQL, paths, hostnames);
        # /status returns error_reason to the end user. Details stay in the log.
        await _record_failure(
            db,
            report_id,
            failure_cat,
            "Report analysis failed unexpectedly. Please try again, or contact "
            "support if the problem continues.",
        )

    finally:
        # Never leave the concurrent medication task running if the pipeline
        # ended early (extraction/LLM failure).
        if med_task is not None and not med_task.done():
            med_task.cancel()
