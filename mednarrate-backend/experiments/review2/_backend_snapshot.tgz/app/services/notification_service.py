import logging

import firebase_admin
from firebase_admin import credentials, messaging
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.notification_log import NotificationLog

logger = logging.getLogger(__name__)

# Initialize FCM globally
try:
    if not firebase_admin._apps:
        import os

        from app.core.config import settings

        cred_path = settings.GOOGLE_APPLICATION_CREDENTIALS or os.environ.get(
            "GOOGLE_APPLICATION_CREDENTIALS"
        )
        if cred_path and os.path.exists(cred_path):
            cred = credentials.Certificate(cred_path)
            firebase_admin.initialize_app(cred)
            logger.info("Firebase Admin initialized with credentials.")
        else:
            logger.info(
                "Firebase Admin initialized (mocked for dev as no credentials exist)."
            )
except Exception as e:
    logger.error(f"Failed to initialize Firebase Admin: {e}")


async def send_push_notification(
    db: AsyncSession,
    user_id: str,
    token: str,
    title: str,
    body: str,
    existing_log: NotificationLog = None,
):
    """Sends a push notification via FCM and logs it."""
    status = "sent"
    error_message = None
    masked_token = f"{token[:6]}…" if token and len(token) > 6 else "***"

    try:
        if firebase_admin._apps:
            message = messaging.Message(
                notification=messaging.Notification(title=title, body=body),
                token=token,
            )
            response = messaging.send(message)
            logger.info(f"Successfully sent message: {response}")
        else:
            raise RuntimeError("FCM Provider not configured. Cannot send notification.")
    except Exception as e:
        status = "failed"
        error_message = str(e)
        logger.error(
            "Error sending push notification to %s: %s",
            masked_token,
            type(e).__name__,
        )

    # Log it
    if existing_log:
        existing_log.status = status
        existing_log.error_message = error_message
        from datetime import datetime

        existing_log.sent_at = datetime.utcnow()
    else:
        log = NotificationLog(
            user_id=user_id,
            title=title,
            body=body,
            status=status,
            error_message=error_message,
        )
        db.add(log)
    await db.commit()
    return status == "sent"
