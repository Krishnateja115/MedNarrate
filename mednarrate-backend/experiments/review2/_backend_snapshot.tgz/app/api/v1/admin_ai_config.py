import re
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.admin_auth import AdminContext, require_permission
from app.core.database import get_db
from app.models.system_setting import SystemSetting
from app.services.audit import log_admin_action

router = APIRouter()


# Providers the runtime can actually build (see LLMClient). A stored name outside this list
# would make every AI request raise "Unknown LLM Provider", so it is refused up front.
PRIMARY_PROVIDERS = frozenset(
    {"gemini", "dev_gemini", "vertex_ai", "ollama", "openai", "anthropic", "mistral",
     "groq", "groq_qwen", "cerebras", "openrouter", "github", "local"}
)
FALLBACK_PROVIDERS = PRIMARY_PROVIDERS | {"fallback", "none"}
_MODEL_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/\-]{0,99}$")


class AIConfigUpdate(BaseModel):
    model_config = ConfigDict(protected_namespaces=())

    primary_provider: Optional[str] = Field(None, example="gemini")
    model_name: Optional[str] = Field(None, example="gemini-3.1-flash-lite")
    temperature: Optional[float] = Field(None, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(None, ge=100, le=32000)
    fallback_provider: Optional[str] = Field(None, example="ollama")
    api_key: Optional[str] = Field(
        None,
        description="Secret API key. Will be stored securely and never returned in plain text.",
    )


@router.get("/ai-config")
async def get_ai_configuration(
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin_ctx: AdminContext = Depends(require_permission("ai_config:read")),
):
    # Show what the app is really using right now (admin override, else environment),
    # not a second set of defaults that could disagree with the runtime.
    from app.services.llm_client import get_resolved_ai_config

    config = await get_resolved_ai_config(db)
    res = await db.execute(select(SystemSetting).where(SystemSetting.category == "ai_config"))
    stored = {s.key for s in res.scalars().all()}
    fallback_provider = config.get("fallback_provider") or "fallback"
    key_is_set = bool(config.get("api_key") and str(config["api_key"]).strip())
    # Never return any portion of the key. Admins see only: is_set true/false.

    return {
        "primary_provider": config.get("primary_provider"),
        "model_name": config.get("model_name"),
        "temperature": config.get("temperature"),
        "max_tokens": config.get("max_tokens"),
        "fallback_provider": fallback_provider,
        "api_key_status": {"is_set": key_is_set},
        # Which values an admin has overridden; the rest come from the server environment.
        "overridden": sorted(k.removeprefix("ai_") for k in stored if k != "ai_api_key"),
    }


@router.put("/ai-config")
async def update_ai_configuration(
    payload: AIConfigUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin_ctx: AdminContext = Depends(require_permission("ai_config:manage")),
):
    if payload.primary_provider is not None and payload.primary_provider.lower().strip() not in PRIMARY_PROVIDERS:
        raise HTTPException(status_code=422, detail=f"Unknown primary provider '{payload.primary_provider}'.")
    if payload.fallback_provider is not None and payload.fallback_provider.lower().strip() not in FALLBACK_PROVIDERS:
        raise HTTPException(status_code=422, detail=f"Unknown fallback provider '{payload.fallback_provider}'.")
    if payload.model_name is not None and not _MODEL_NAME_RE.match(payload.model_name.strip()):
        raise HTTPException(status_code=422, detail="Model name may only contain letters, digits and . _ : / -")

    async def _upsert_setting(
        key: str, val: str, is_sensitive: bool = False, description: str = ""
    ):
        res = await db.execute(select(SystemSetting).where(SystemSetting.key == key))
        record = res.scalar_one_or_none()
        if not record:
            record = SystemSetting(
                id=uuid.uuid4(),
                key=key,
                value=val,
                category="ai_config",
                is_sensitive=is_sensitive,
                description=description,
                updated_by_id=admin_ctx.user_id,
            )
            db.add(record)
        else:
            record.value = val
            record.is_sensitive = is_sensitive
            record.updated_by_id = admin_ctx.user_id

    changes = {}
    if payload.primary_provider is not None:
        await _upsert_setting(
            "ai_primary_provider",
            payload.primary_provider.lower().strip(),
            False,
            "Primary AI Provider",
        )
        changes["primary_provider"] = payload.primary_provider.lower().strip()

    if payload.model_name is not None:
        await _upsert_setting(
            "ai_model_name", payload.model_name.strip(), False, "AI Model Name"
        )
        changes["model_name"] = payload.model_name

    if payload.temperature is not None:
        await _upsert_setting(
            "ai_temperature", str(payload.temperature), False, "Sampling Temperature"
        )
        changes["temperature"] = payload.temperature

    if payload.max_tokens is not None:
        await _upsert_setting(
            "ai_max_tokens", str(payload.max_tokens), False, "Max Tokens output limit"
        )
        changes["max_tokens"] = payload.max_tokens

    if payload.fallback_provider is not None:
        await _upsert_setting(
            "ai_fallback_provider",
            payload.fallback_provider.lower().strip(),
            False,
            "Fallback AI Provider",
        )
        changes["fallback_provider"] = payload.fallback_provider.lower().strip()

    if payload.api_key is not None and payload.api_key.strip():
        from app.core.encryption import encrypt_value
        encrypted_key = encrypt_value(payload.api_key.strip())
        await _upsert_setting(
            "ai_api_key", encrypted_key, True, "AI Provider API Key"
        )
        changes["api_key"] = "[UPDATED_SENSITIVE]"

    # Audit BEFORE commit — both config change and audit record are atomic
    await log_admin_action(
        db=db,
        actor_admin_id=admin_ctx.user_id,
        action="ai_config_update",
        resource_type="system_setting",
        resource_id="ai_config",
        permission_used="ai_config:manage",
        result="success",
        reason="Updated AI operational configuration",
        request=request,
        # api_key value is never included — sanitize_metadata also covers this
        metadata={"changes": changes},
        sensitive_access_flag=True if "api_key" in changes else False,
    )

    # Single commit: settings + audit event together
    await db.commit()

    return {
        "message": "AI configuration updated successfully",
        "updated_fields": list(changes.keys()),
    }


@router.post("/ai-config/test-credential")
async def test_ai_credential(
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin_ctx: AdminContext = Depends(require_permission("ai_config:manage")),
):
    """
    Tests the currently configured AI provider credential without returning or exposing it.
    Returns: {reachable, authenticated, model_available, request_successful}
    """
    from app.services.llm_client import llm_client_instance, get_resolved_ai_config

    try:
        config = await get_resolved_ai_config()
        provider_name = config.get("primary_provider", "auto").lower().strip()
        provider = llm_client_instance.get_provider(provider_name)
        health = await provider.health_check(config=config)

        # Perform a real bounded provider request
        request_successful = False
        error_summary = None
        if health.get("reachable", False):
            try:
                await provider.generate("Test connection", timeout=5.0, config=config)
                request_successful = True
            except Exception as e:
                request_successful = False
                error_summary = str(e)
        else:
            error_summary = "Provider not reachable based on health check."

        health["request_successful"] = request_successful
        if error_summary:
            health["error_summary"] = error_summary

        await log_admin_action(
            db=db,
            actor_admin_id=admin_ctx.user_id,
            action="ai_config_test_credential",
            resource_type="system_setting",
            resource_id="ai_config",
            permission_used="ai_config:manage",
            result="success",
            request=request,
            metadata={
                "provider": provider_name,
                "health_result": {k: v for k, v in health.items() if k != "api_key"},
            },
        )
        await db.commit()

        # Never return the key — only return diagnostic flags
        return {
            "provider": provider_name,
            "reachable": health.get("reachable", False),
            "configured": health.get("configured", False),
            "request_successful": request_successful,
            "error_summary": health.get("error_summary", None)
            if not request_successful
            else None,
        }
    except Exception as exc:
        await log_admin_action(
            db=db,
            actor_admin_id=admin_ctx.user_id,
            action="ai_config_test_credential",
            resource_type="system_setting",
            resource_id="ai_config",
            permission_used="ai_config:manage",
            result="failure",
            request=request,
            metadata={"provider": "unknown", "error": str(exc)},
        )
        await db.commit()
        return {
            "provider": "unknown",
            "reachable": False,
            "configured": False,
            "request_successful": False,
            "error_summary": "Provider check failed or exception occurred.",
        }
