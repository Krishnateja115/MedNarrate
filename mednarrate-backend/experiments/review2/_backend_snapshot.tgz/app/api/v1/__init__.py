from fastapi import APIRouter

from .admin import router as admin_router
from .analysis import router as analysis_router
from .auth import router as auth_router
from .chat import router as chat_router
from .health import router as health_router
from .notifications import router as notifications_router
from .password_reset import router as password_reset_router
from .reminders import router as reminders_router
from .reports import router as reports_router
from .speech import router as speech_router
from .support import router as support_router
from .users import router as users_router
from .mfa import router as mfa_router
from .ml import router as ml_router

router = APIRouter()
router.include_router(auth_router, prefix="/auth", tags=["auth"])
router.include_router(users_router, prefix="/users", tags=["users"])
router.include_router(reports_router, prefix="/reports", tags=["reports"])
router.include_router(analysis_router, prefix="/reports", tags=["analysis"])
router.include_router(chat_router, prefix="/chat", tags=["chat"])
router.include_router(
    notifications_router, prefix="/notifications", tags=["notifications"]
)
router.include_router(password_reset_router, prefix="/auth", tags=["password-reset"])
router.include_router(health_router, prefix="/health", tags=["health"])
router.include_router(reminders_router, prefix="/reminders", tags=["reminders"])
router.include_router(support_router, prefix="/support", tags=["support"])
router.include_router(admin_router, prefix="/admin", tags=["admin"])
router.include_router(mfa_router, prefix="/mfa", tags=["mfa"])
router.include_router(speech_router, prefix="/speech", tags=["speech"])
router.include_router(ml_router, prefix="/ml", tags=["ml"])
